Run example.m for FBLG demostration. 

Please specify the directory to glmnet_matlab package in example.m

