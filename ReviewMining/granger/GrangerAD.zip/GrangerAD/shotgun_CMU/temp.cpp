#include "mex.h"
#include <iostream>
#include <omp.h>
#include <fstream>
#include <cmath>
#include <time.h>
#include <stdlib.h>

using namespace std;

void mexFunction( int nlhs, mxArray *plhs[], 
		  int nrhs, const mxArray*prhs[] )
     
{ 
    mexPrintf("hi\n");
}