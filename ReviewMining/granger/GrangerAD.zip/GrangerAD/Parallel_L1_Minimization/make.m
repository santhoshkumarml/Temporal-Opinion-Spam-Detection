addpath('SCD');
mex 'mex_PStocSubGD.cpp'
mex 'mex_PSGD_Yahoo.cpp'
mex 'mex_SGLD.cpp'
mex 'SCD/mex_SCD.cpp'