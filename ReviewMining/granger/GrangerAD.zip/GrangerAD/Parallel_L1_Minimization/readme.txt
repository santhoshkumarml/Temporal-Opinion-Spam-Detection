Compile the cpp file by executing make.m
The main function is lasso_granger.m
See examples in test.m

