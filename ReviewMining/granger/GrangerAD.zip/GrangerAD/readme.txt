************************************************************
* Code for anomaly detection using Granger graphical models*
* by Huida Qiu                                             *
************************************************************

granger_anomaly_detetion.m and granger_stoc_anomaly_detection.m are the main functions. The latter one uses stochastic methods for L1-regularized regression.

The other functions and packages are required in these two main functions.

TE_test_script.m and test_StocMethods.m show examples how to use the functions.

